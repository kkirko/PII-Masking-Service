# Watsonx Offline Demo (No Internet)

Step 1: upload watsonx-offline-demo.zip as asset
Step 2: create notebook
Step 3: insert project token and run it (so wslib exists)

One cell:
```python
import sys
import zipfile
from pathlib import Path
import wslib

wslib.download_file("watsonx-offline-demo.zip")
with zipfile.ZipFile("watsonx-offline-demo.zip", "r") as z:
    z.extractall("watsonx-offline-demo")
sys.path.insert(0, str(Path("watsonx-offline-demo").resolve()))
from watsonx_demo import show_demo
show_demo()
```

Note: Requires pydantic>=2.0.0 and cryptography>=41.0.0.
